# Stop Billing Function

This function will remove the billing account associated with the project if the cost amount is higher than the budget amount.